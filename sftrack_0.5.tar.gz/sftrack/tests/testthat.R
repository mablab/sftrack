library(testthat)
library(sftrack)
# library(adehabitatLT)
test_check("sftrack")
